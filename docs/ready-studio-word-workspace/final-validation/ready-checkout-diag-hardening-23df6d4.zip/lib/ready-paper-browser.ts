import { drawReadyText } from "./ready-text-block";
import { paperFonts, type PaperFont } from "./paper-fonts";
import {
  cleanPixels,
  reduceBlueWatermark,
  type PageEdit,
} from "./ready-papers";
import { loadBrowserPdfEngine } from "./pdf-engine-browser";
export const loadReadyPdfEngine = loadBrowserPdfEngine;
/** One live PDF document per source URL: thumbnails already fetch the file,
    and checkout re-renders those same pages — a second network fetch must
    never gate payment preparation. Failed fetches drop out for a clean retry. */
const pdfDocs = new Map<string, Promise<any>>();
function loadPdfDocument(url: string) {
  let doc = pdfDocs.get(url);
  if (!doc) {
    doc = loadReadyPdfEngine()
      .then((pdfjs) =>
        pdfjs.getDocument({
          url,
          isEvalSupported: false,
          disableFontFace: true,
        }).promise,
      )
      .catch((e) => {
        pdfDocs.delete(url);
        throw e;
      });
    pdfDocs.set(url, doc);
    if (pdfDocs.size > 3) {
      const oldest = pdfDocs.keys().next().value;
      if (oldest !== undefined) {
        const dropped = pdfDocs.get(oldest);
        pdfDocs.delete(oldest);
        dropped?.then((d: any) => d?.destroy?.()).catch(() => {});
      }
    }
  }
  return doc;
}
export async function loadPdfImages(
  url: string,
  onProgress: (n: number, total: number) => void,
  selected?: number[],
) {
  const doc = await loadPdfDocument(url);
  const images: string[] = [];
  if (doc.numPages > 100)
    throw Error("এক PDF-এ সর্বোচ্চ ১০০ page। ছোট ভাগে upload করুন।");
  const indices =
    selected ?? Array.from({ length: doc.numPages }, (_, i) => i + 1);
  for (const i of indices) {
    if (!Number.isInteger(i) || i < 1 || i > doc.numPages)
      throw Error("অবৈধ page");
    const page = await doc.getPage(i),
      v = page.getViewport({ scale: 1 }),
      scale = Math.min(
        4,
        (selected ? 2400 : 900) / Math.max(v.width, v.height),
      ),
      vp = page.getViewport({ scale });
    if (vp.width < 1 || vp.height < 1) throw Error("অবৈধ page");
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(vp.width);
    canvas.height = Math.ceil(vp.height);
    await page.render({
      canvasContext: canvas.getContext("2d"),
      viewport: vp,
      background: "white",
    }).promise;
    images.push(canvas.toDataURL("image/jpeg", 0.94));
    canvas.width = canvas.height = 0;
    page.cleanup();
    onProgress(i, doc.numPages);
  }
  return images;
}
export function imageFrom(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(Error(`Page image লোড হয়নি (${url.length} chars)`));
      reject(Error(`Page image load failed (${url.length} chars)`));
    image.src = url;
  });
}
export async function renderEdited(
  url: string,
  edit: PageEdit,
  includeMarks = true,
  font: PaperFont = "kalpurush",
) {
  const image = await imageFrom(url),
    canvas = document.createElement("canvas");
  try {
  const rotate = edit.rotation === 90 || edit.rotation === 270;
  canvas.width = rotate ? image.height : image.width;
  canvas.height = rotate ? image.width : image.height;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(((edit.rotation + edit.deskew) * Math.PI) / 180);
  ctx.drawImage(image, -image.width / 2, -image.height / 2);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (edit.blueWatermark > 0) {
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
    reduceBlueWatermark(pixels.data, edit.blueWatermark);
    ctx.putImageData(pixels, 0, 0);
  }
  if (edit.mode !== "original") {
    const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
    cleanPixels(
      pixels.data,
      canvas.width,
      canvas.height,
      edit.strength,
      edit.mode === "bw",
    );
    ctx.putImageData(pixels, 0, 0);
  }
  if (includeMarks) {
    for (const m of edit.masks) {
      ctx.fillStyle = "#fff";
      ctx.fillRect(
        m.x * canvas.width,
        m.y * canvas.height,
        m.w * canvas.width,
        m.h * canvas.height,
      );
    }
    const fontFamily = (paperFonts[font] || paperFonts.kalpurush).replace(/var\((--[a-z-]+)\)/g, (_,name)=>getComputedStyle(document.documentElement).getPropertyValue(name).trim() || "serif");
    // Preload is best-effort: a slow or failed font fetch must never block checkout.
    const fontLoad = document.fonts.load(`16px ${fontFamily}`).catch((fe) => {
      console.error("font preload failed; rendering with fallback", fe);
    });
    await Promise.race([
      fontLoad,
      new Promise((r) => setTimeout(r, 3000)),
    ]);
    for (const t of edit.texts) {
      try {
        drawReadyText(ctx,t,canvas.width,canvas.height,fontFamily);
      } catch (te) {
        console.error("editable text draw failed", te);
      }
    }
  }
  const output = document.createElement("canvas");
  output.width = Math.max(
    1,
    Math.round(canvas.width * (1 - edit.left - edit.right)),
  );
  output.height = Math.max(
    1,
    Math.round(canvas.height * (1 - edit.top - edit.bottom)),
  );
  output
    .getContext("2d")!
    .drawImage(
      canvas,
      edit.left * canvas.width,
      edit.top * canvas.height,
      output.width,
      output.height,
      0,
      0,
      output.width,
      output.height,
    );
  return output;
  } finally {
    canvas.width = canvas.height = 0;
  }
}
/** Conservative suggestion: trim only almost-white outside margins, never guess publication text. */
export async function suggestMargins(url: string) {
  const image = await imageFrom(url),
    canvas = document.createElement("canvas");
  canvas.width = 300;
  canvas.height = Math.round((300 * image.height) / image.width);
  const c = canvas.getContext("2d")!;
  c.drawImage(image, 0, 0, canvas.width, canvas.height);
  const { data } = c.getImageData(0, 0, canvas.width, canvas.height);
  const row = (y: number) => {
    let dark = 0;
    for (let x = 0; x < canvas.width; x++)
      if (data[(y * canvas.width + x) * 4] < 220) dark++;
    return dark > 2;
  };
  let top = 0,
    bottom = 0;
  while (top < canvas.height * 0.08 && !row(top)) top++;
  while (bottom < canvas.height * 0.08 && !row(canvas.height - 1 - bottom))
    bottom++;
  return {
    top: Math.max(0, (top - 4) / canvas.height),
    bottom: Math.max(0, (bottom - 4) / canvas.height),
  };
}
export async function saveLocal(key: string, value: unknown) {
  const db = await openLocal();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("drafts", "readwrite");
      tx.objectStore("drafts").put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } finally {
    db.close();
  }
}
export async function loadLocal(key: string) {
  const db = await openLocal();
  try {
    return await new Promise<any>((resolve, reject) => {
      const r = db.transaction("drafts").objectStore("drafts").get(key);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  } finally {
    db.close();
  }
}
function openLocal(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open("qm-ready-studio", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("drafts");
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

/** Text layer only; not OCR. Legacy Bengali fonts may produce unreadable text. */
export async function readReadyPageText(url: string, page: number) {
  const pdfjs = await loadReadyPdfEngine();
  if (!pdfjs) throw Error("আগে PDF খুলুন।");
  const task = pdfjs.getDocument({
    url,
    isEvalSupported: false,
    disableFontFace: true,
  });
  const doc = await task.promise;
  try {
    if (
      !Number.isInteger(page) ||
      page < 1 ||
      page > doc.numPages ||
      doc.numPages > 100
    )
      throw Error("অবৈধ page");
    const content = await (await doc.getPage(page)).getTextContent();
    return content.items
      .map((item: any) => item.str || "")
      .join(" ")
      .slice(0, 20000);
  } finally {
    await doc.destroy();
  }
}
