"use client";
import { type RasterBox, type ReadyTextStyle } from "@/lib/ready-text-block";
import { paperFonts, paperFontLabels, type PaperFont } from "@/lib/paper-fonts";
import { paperMarginMode, paperMarginPresets } from "@/lib/paper-margins";
import { toPng } from "html-to-image";
import {
  beginReadyMarketExport,
  uploadReadyMarketPage,
} from "@/app/actions/marketplace-ready";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import ReadyTextEditor from "./text-editor";
import ReadyCheckout from "./checkout";
import { selectionWithPage } from "@/lib/ready-page-selection";
import {
  getReadyPurchase,
  saveReadyPurchase,
  type ReadyPurchase,
} from "@/app/actions/ready-commerce";
import {
  readySelectionIdentity,
  type ReadySnapshot,
} from "@/lib/ready-commerce";
import PageLoader from "./page-loader";
import RasterTools from "./raster-tools";
import { rasterEditKey, type RasterPoint } from "@/lib/ready-raster";
import PlacedQuestion from "./placed-question";
import { defaultPlacement, type Placement } from "@/lib/ready-placement";
import HeaderManager from "@/components/paper-builder/header-manager";
import HeaderPreview from "@/components/paper-builder/header-preview";
import { settingsSchema } from "@/lib/paper-builder";
import { currentHeader } from "@/lib/paper-header";
import "@/components/paper-builder/header.css";
import { PageViewer, PrintFrame } from "./page-viewer";
import {
  ArrowLeft,
  Check,
  FileText,
  RotateCw,
  Undo2,
  Redo2,
  Printer,
  Save,
  Crop,
  Eraser,
  Type,
  Sparkles,
} from "lucide-react";
import {
  freshEdit,
  pageEditSchema,
  type PageEdit,
  type ReadyPaper,
} from "@/lib/ready-papers";
import {
  loadPdfImages,
  renderEdited,
  suggestMargins,
  saveLocal,
  loadLocal,
} from "@/lib/ready-paper-browser";
import { updateReadyPaper } from "@/app/actions/ready-papers";
import "./ready.css";
import type { ReadyAnswer } from "@/lib/ready-answers";
type Header = {
  school: string;
  exam: string;
  subject: string;
  time: string;
  marks: string;
};
export default function ReadyStudio({
  paper,
  userId,
  adminPreset,
  answerEntries = [],
  initialPurchase,
}: {
  paper: ReadyPaper;
  userId: string;
  adminPreset: boolean;
  answerEntries?: ReadyAnswer[];
  initialPurchase?: ReadyPurchase;
}) {
  const [checkout, setCheckout] = useState(false);
  const [saveNotice, setSaveNotice] = useState("");
  const [exportingMarket, setExportingMarket] = useState(false);
  const explicitlySaved = useRef("");
  const hydratedPurchase = useRef("");
  const [receipt, setReceipt] = useState(initialPurchase?.id ?? "");
  const [paidSelection, setPaidSelection] = useState(
    initialPurchase ? readySelectionIdentity(initialPurchase.selected) : "",
  );
  const [pageLoading, setPageLoading] = useState(true);
  const [pageProgress, setPageProgress] = useState({ completed: 0, total: 0 });
  const [liveReviewPage, setLiveReviewPage] = useState(0);
  const [liveReview, setLiveReview] = useState("");
  const [reviewPending, setReviewPending] = useState(false);
  const [replacementBox, setReplacementBox] = useState<RasterBox | null>(null);
  const [textStyle, setTextStyle] = useState<ReadyTextStyle>({});
  const [editingText, setEditingText] = useState<number | null>(null);
  const [ocrBusy, setOcrBusy] = useState(false);
  const ocrAbort = useRef<AbortController | null>(null);
  useEffect(() => () => ocrAbort.current?.abort(), []);

  const [headerLine, setHeaderLine] = useState(true);
  const [headerGap, setHeaderGap] = useState(2);
  const [placementMode, setPlacementMode] = useState(false);
  const [headerStyle, setHeaderStyle] = useState<"simple" | "custom" | "none">(
    "simple",
  );
  const [headerSettings, setHeaderSettings] = useState(() =>
    settingsSchema.parse({
      info: { subject: paper.subject, cls: paper.grade },
    }),
  );
  const [viewer, setViewer] = useState<{
    src: string;
    page: number;
    selectable: boolean;
  } | null>(null);
  const [controlsOpen, setControlsOpen] = useState(false);
  const controlsPanel = useRef<HTMLElement>(null);
  const controlsToggle = useRef<HTMLButtonElement>(null);
  const printKind = "questions";
  const previewInFlight = useRef(false);
  const pendingAutoSave = useRef<Promise<unknown>>(Promise.resolve());
  const [pages, setPages] = useState<string[]>([]),
    [selected, setSelected] = useState<number[]>([]),
    [edits, setEdits] = useState<Record<string, PageEdit>>(paper.presets),
    [step, setStep] = useState<"select" | "edit" | "preview">("select"),
    [active, setActive] = useState(1),
    [message, setMessage] = useState("PDF খোলা হচ্ছে…"),
    [busy, setBusy] = useState(true),
    [tool, setTool] = useState<"view" | "erase" | "text" | "replace">("view"),
    [text, setText] = useState(""),
    [size, setSize] = useState(20),
    [original, setOriginal] = useState(false),
    [printPages, setPrintPages] = useState<string[]>([]),
    [header, setHeader] = useState<Header>({
      school: "",
      exam: "",
      subject: paper.subject,
      time: "",
      marks: "",
    });
  const undo = useRef<Record<number, PageEdit[]>>({}),
    redo = useRef<Record<number, PageEdit[]>>({}),
    key = `${userId}:${paper.id}`,
    edit = edits[String(active)] || freshEdit();
  useEffect(() => {
    ocrAbort.current?.abort();
    setReplacementBox(null);
    setEditingText(null);
  }, [active]);
  const rasterKey = rasterEditKey(edit);
  const qualityCache = useRef(new Map<number, Promise<string>>());
  function qualityPage(n: number) {
    let promise = qualityCache.current.get(n);
    if (!promise) {
      promise = loadPdfImages(paper.url, () => {}, [n])
        .then((p) => p[0])
        .catch((e) => {
          qualityCache.current.delete(n);
          throw e;
        });
      qualityCache.current.set(n, promise);
      if (qualityCache.current.size > 10) {
        const oldest = qualityCache.current.keys().next().value;
        if (oldest !== undefined) qualityCache.current.delete(oldest);
      }
    }
    return promise;
  }
  function snapshot(): ReadySnapshot {
    return {
      edits,
      header,
      headerStyle,
      headerSettings,
      headerLine,
      headerGap,
    };
  }
  const paid =
    adminPreset ||
    (!!receipt && paidSelection === readySelectionIdentity(selected));
  function openSetup(selection: number[]) {
    if (busy || !selection.length) return;
    // Check the new selection, not the previous render's paid flag.
    const selectionPaid =
      adminPreset ||
      (!!receipt && paidSelection === readySelectionIdentity(selection));
    if (selectionPaid) {
      setActive(selection[0]);
      setStep("edit");
    } else setCheckout(true);
  }
  useEffect(() => {
    if (
      controlsOpen &&
      step === "edit" &&
      window.matchMedia("(max-width: 639px)").matches
    ) {
      controlsPanel.current?.focus({ preventScroll: true });
      controlsPanel.current?.scrollIntoView({
        block: "start",
        behavior: "auto",
      });
    }
  }, [controlsOpen, step]);
  function closeControls() {
    setControlsOpen(false);
    controlsToggle.current?.focus({ preventScroll: true });
    controlsToggle.current?.scrollIntoView({
      block: "start",
      behavior: "auto",
    });
  }
  function startSetup() {
    openSetup(selected);
  }
  function createFromPage(page: number) {
    if (busy) return;
    const next = selectionWithPage(selected, page);
    if (!next) {
      setMessage(
        "একবারে সর্বোচ্চ ১০ page নির্বাচন করুন। নতুন পেজ নিতে আগে একটি টিক সরান।",
      );
      return;
    }
    setSelected(next);
    openSetup(next);
  }
  useEffect(() => {
    if (!initialPurchase) return;
    const p = initialPurchase;
    // Server-action revalidation can deliver a new object for the same receipt.
    // Do not reset current edits/step after Save or during Preview preparation.
    if (hydratedPurchase.current === p.id) return;
    hydratedPurchase.current = p.id;
    explicitlySaved.current = "";
    setSelected(p.selected);
    setActive(p.selected[0]);
    setEdits(p.snapshot.edits);
    setHeader(p.snapshot.header);
    setHeaderStyle(p.snapshot.headerStyle);
    setHeaderSettings(p.snapshot.headerSettings);
    setHeaderLine(p.snapshot.headerLine);
    setHeaderGap(p.snapshot.headerGap);
    setStep("edit");
  }, [initialPurchase]);
  useEffect(() => {
    let live = true;
    setBusy(true);
    qualityCache.current.clear();
    setPageLoading(true);
    setPages([]);
    setPageProgress({ completed: 0, total: 0 });
    loadPdfImages(paper.url, (n, total) => {
      if (live) setPageProgress({ completed: n, total });
    })
      .then((p) => {
        if (live) {
          setPageLoading(false);
          setPages(p);
          setMessage("Page বেছে সেটআপে যান।");
          setBusy(false);
        }
      })
      .catch((e) => {
        if (live) {
          setPageLoading(false);
          setMessage(e.message || "PDF খোলা যায়নি। আবার চেষ্টা করুন।");
          setBusy(false);
        }
      });
    return () => {
      live = false;
    };
  }, [paper.url]);
  useEffect(() => {
    if (step !== "edit" || !pages[active - 1]) return;
    let live = true;
    setReviewPending(true);
    const timer = setTimeout(async () => {
      try {
        await document.fonts.ready;
        const rasterEdit = JSON.parse(rasterKey) as PageEdit;
        const result = await renderEdited(
          await qualityPage(active),
          original
            ? { ...freshEdit(), rotation: rasterEdit.rotation }
            : rasterEdit,
          true,
          headerSettings.cfg.font,
        );
        if (live) {
          setLiveReview(result.toDataURL("image/png"));
          setLiveReviewPage(active);
        }
        result.width = result.height = 0;
      } catch (error) {
        if (live) {
          setLiveReview("");
          setMessage(
            error instanceof Error ? error.message : "প্রিভিউ তৈরি হয়নি।",
          );
        }
      } finally {
        if (live) setReviewPending(false);
      }
    }, 120);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [pages, active, rasterKey, step, original, headerSettings.cfg.font]);
  const sheetStyle = {
    fontFamily: paperFonts[headerSettings.cfg.font],
    padding: `${headerSettings.cfg.marginTop}px ${headerSettings.cfg.marginRight}px ${headerSettings.cfg.marginBottom}px ${headerSettings.cfg.marginLeft}px`,
  };
  function renderPageHeader(first: boolean) {
    return (
      <>
        {first && headerStyle === "custom" && headerSettings.header.enabled && (
          <header
            className={`rp-custom-print-header rp-adjustable-header ${headerLine ? "" : "rp-header-line-off"}`}
            style={{ marginBottom: `${headerGap}mm` }}
          >
            <HeaderPreview header={currentHeader(headerSettings)} />
          </header>
        )}
        {first &&
          headerStyle === "simple" &&
          Object.values(header).some(Boolean) && (
            <header
              className={`rp-print-header rp-adjustable-header ${headerLine ? "" : "rp-header-line-off"}`}
              style={{ marginBottom: `${headerGap}mm` }}
            >
              <h2>{header.school}</h2>
              <h3>{header.exam}</h3>
              <p>{header.subject}</p>
              <div>
                <span>{header.time && `সময়: ${header.time}`}</span>
                <span>{header.marks && `পূর্ণমান: ${header.marks}`}</span>
              </div>
            </header>
          )}
      </>
    );
  }
  useEffect(() => {
    if (!paid || adminPreset || !receipt || step === "select" || busy) return;
    let live = true;
    const timer = setTimeout(() => {
      pendingAutoSave.current = pendingAutoSave.current
        .catch(() => {})
        .then(() => saveReadyPurchase(receipt, snapshot(), selected))
        .then((r) => {
          if (live && !r.ok) setMessage("Account auto-save হয়নি: " + r.error);
        })
        .catch(() => {
          if (live)
            setMessage("Account auto-save হয়নি। প্রশ্নপত্র সেভ করুন চাপুন।");
        });
    }, 1200);
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [
    paid,
    selected,
    receipt,
    step,
    edits,
    header,
    headerStyle,
    headerSettings,
    headerLine,
    headerGap,
    adminPreset,
    busy,
  ]);
  function togglePage(n: number) {
    setSelected((old) => {
      if (old.includes(n)) return old.filter((v) => v !== n);
      if (old.length >= 10) return old;
      return [...old, n];
    });
    if (!selected.includes(n) && selected.length >= 10)
      setMessage("একবারে সর্বোচ্চ ১০ page নির্বাচন করুন।");
  }
  function placePage(page: number, placement: Placement) {
    setEdits((old) => ({
      ...old,
      [page]: pageEditSchema.parse({
        ...freshEdit(),
        ...old[page],
        ...placement,
      }),
    }));
  }
  function update(patch: Partial<PageEdit>) {
    const checked = pageEditSchema.safeParse({ ...edit, ...patch });
    if (!checked.success) {
      setMessage(
        "এই page-এর edit সীমা পূর্ণ অথবা crop অবৈধ। Undo/Reset করে চেষ্টা করুন।",
      );
      return;
    }
    const next = checked.data;
    undo.current[active] = [
      ...(undo.current[active] || []).slice(-19),
      structuredClone(edit),
    ];
    redo.current[active] = [];
    setEdits((old) => ({ ...old, [active]: next }));
    setPrintPages([]);
  }
  function history(back: boolean) {
    const from = back ? undo : redo,
      to = back ? redo : undo,
      old = from.current[active]?.pop();
    if (old) {
      to.current[active] = [
        ...(to.current[active] || []),
        structuredClone(edit),
      ];
      setEdits((v) => ({ ...v, [active]: old }));
      setPrintPages([]);
    }
  }
  function commitRaster(start: RasterPoint, end: RasterPoint) {
    if (original || reviewPending) return;
    if (tool === "replace") {
      const box = {
        x: Math.min(start.x, end.x),
        y: Math.min(start.y, end.y),
        w: Math.abs(end.x - start.x),
        h: Math.abs(end.y - start.y),
      };
      if (box.w > 0.01 && box.h > 0.01 && box.x <= 0.95 && box.y <= 0.98) {
        setReplacementBox(box);
        setEditingText(null);
        setText("");
        setControlsOpen(true);
      }
      return;
    }
    if (tool === "erase") {
      const box = {
        x: Math.min(start.x, end.x),
        y: Math.min(start.y, end.y),
        w: Math.abs(end.x - start.x),
        h: Math.abs(end.y - start.y),
      };
      if (busy) return;
      if (box.w > 0.003 && box.h > 0.003 && edit.masks.length < 40)
        update({ masks: [...edit.masks, box] });
    } else if (tool === "text" && text.trim() && edit.texts.length < 30)
      update({
        texts: [
          ...edit.texts,
          {
            x: Math.min(0.95, start.x),
            y: Math.min(0.98, start.y),
            text: text.trim(),
            size,
            style: textStyle,
          },
        ],
      });
  }
  async function readRegion() {
    if (!replacementBox || ocrBusy || !paid) return;
    ocrAbort.current?.abort();
    const controller = new AbortController();
    ocrAbort.current = controller;
    setOcrBusy(true);
    try {
      const { readReadyRegion } = await import("@/lib/ready-region-ocr");
      const result = await readReadyRegion(
        await qualityPage(active),
        edit,
        replacementBox,
        controller.signal,
        setMessage,
      );
      if (!controller.signal.aborted) {
        setText(result.text);
        setMessage(
          `OCR পড়া হয়েছে (${Math.round(result.confidence)}%)। ভুল/গণিত/চিত্র যাচাই করে প্রয়োগ করুন; নিজে থেকে মূল ছবি বদলায়নি।`,
        );
      }
    } catch (error) {
      if (!controller.signal.aborted)
        setMessage(error instanceof Error ? error.message : "OCR হয়নি।");
    } finally {
      setOcrBusy(false);
    }
  }
  function applyReplacement() {
    if (!replacementBox || !text.trim() || busy) return;
    const value = {
      x: replacementBox.x,
      y: replacementBox.y,
      w: replacementBox.w,
      h: replacementBox.h,
      text: text.trim(),
      size,
      style: textStyle,
    };
    if (editingText !== null) {
      update({
        texts: edit.texts.map((t, i) => (i === editingText ? value : t)),
      });
    } else {
      if (edit.texts.length >= 30 || edit.masks.length >= 40) {
        setMessage(
          "এই পৃষ্ঠার সম্পাদনার সীমা পূর্ণ। আগে অপ্রয়োজনীয় লেখা সরান।",
        );
        return;
      }
      update({
        masks: [...edit.masks, replacementBox],
        texts: [...edit.texts, value],
      });
    }
    setReplacementBox(null);
    setEditingText(null);
    setTool("view");
  }
  function saveIdentity() {
    return JSON.stringify({ receipt, selected, snapshot: snapshot() });
  }
  const latestSaveIdentity = useRef("");
  latestSaveIdentity.current = saveIdentity();
  function requireSaved() {
    if (explicitlySaved.current === saveIdentity()) return true;
    const notice =
      "আগে ‘প্রশ্নপত্র সেভ করুন’ চাপুন। সফলভাবে সেভ হলে Print Preview খুলতে পারবেন।";
    setMessage(notice);
    setSaveNotice(notice);
    return false;
  }
  async function preview() {
    if (busy) return;
    if (!paid) {
      setCheckout(true);
      return;
    }
    if (!requireSaved()) return;
    const previewIdentity = saveIdentity();
    setBusy(true);
    setMessage("Print preview প্রস্তুত হচ্ছে…");
    setSaveNotice("Print Preview-এর পৃষ্ঠাগুলো প্রস্তুত হচ্ছে…");
    try {
      await document.fonts.ready;
      const out = [];
      for (const n of selected) {
        const c = await renderEdited(
          await qualityPage(n),
          edits[n] || freshEdit(),
          true,
          headerSettings.cfg.font,
        );
        out.push(c.toDataURL("image/png"));
        c.width = c.height = 0;
      }
      if (latestSaveIdentity.current !== previewIdentity)
        throw Error(
          "প্রস্তুতির সময় সম্পাদনা বদলেছে। আবার Save & Print Preview চাপুন।",
        );
      setPrintPages(out);
      setStep("preview");
      setMessage("Preview দেখে print করুন।");
      setSaveNotice(
        "Preview প্রস্তুত। নিচে প্রিন্ট বা ‘Marketplace-এ বিক্রির কপি প্রস্তুত করুন’ বেছে নিন।",
      );
    } catch (error) {
      const notice =
        "Print Preview খোলেনি: " +
        (error instanceof Error
          ? error.message
          : "সংযোগ বা PDF-এর ছবি প্রস্তুত হয়নি। আবার চেষ্টা করুন।");
      setMessage(notice);
      setSaveNotice(notice);
    } finally {
      setBusy(false);
    }
  }
  async function prepareMarketCopy() {
    if (
      busy ||
      !paid ||
      !receipt ||
      printKind !== "questions" ||
      !requireSaved()
    )
      return;
    if (
      !window.confirm(
        "এই দৃশ্যমান প্রশ্নপত্রের স্থির ছবিভিত্তিক কপি বিক্রির আবেদনের জন্য প্রস্তুত করবেন? নিজের বা যথাযথ বিক্রির অধিকার থাকা বিষয়বস্তুই জমা দিন। মূল PDF-এর অন্য পৃষ্ঠা যাবে না।",
      )
    )
      return;
    setBusy(true);
    setExportingMarket(true);
    try {
      const sheets = [
        ...document.querySelectorAll<HTMLElement>(
          "#ready-print .rp-print-sheet",
        ),
      ];
      if (sheets.length !== selected.length)
        throw Error("আগে প্রশ্নপত্রের Print Preview প্রস্তুত করুন।");
      // Sync the exact latest snapshot before freezing; no extra checkout or wallet debit.
      const saved = await saveReadyPurchase(receipt, snapshot(), selected);
      if (!saved.ok) throw Error(saved.error);
      const batch = await beginReadyMarketExport(receipt);
      if (!batch.ok) throw Error(batch.error);
      if (batch.count !== sheets.length) throw Error("পৃষ্ঠা নির্বাচন বদলেছে।");
      await document.fonts.ready;
      for (let i = 0; i < sheets.length; i++) {
        setSaveNotice(
          `বিক্রির স্থির কপি প্রস্তুত হচ্ছে: ${i + 1}/${sheets.length}`,
        );
        await Promise.all(
          [...sheets[i].querySelectorAll("img")].map((img) => img.decode()),
        );
        const png = await toPng(sheets[i], {
          pixelRatio: 1,
          backgroundColor: "#ffffff",
          filter: (node) =>
            !(node instanceof HTMLElement && node.hasAttribute("data-noprint")),
        });
        const page = await (await fetch(png)).blob();
        const form = new FormData();
        form.set("receiptId", receipt);
        form.set("hash", batch.hash);
        form.set("batchId", batch.batchId);
        form.set("index", String(i));
        form.set("page", page, `page-${i}.png`);
        const result = await uploadReadyMarketPage(form);
        if (!result.ok) throw Error(result.error);
      }
      window.location.assign("/dashboard/sell");
    } catch (e) {
      setSaveNotice(
        e instanceof Error
          ? e.message
          : "বিক্রির কপি প্রস্তুত হয়নি। আবার চেষ্টা করুন।",
      );
    } finally {
      setBusy(false);
      setExportingMarket(false);
    }
  }
  async function save(): Promise<boolean> {
    if (busy) return false;
    if (!adminPreset && !paid) {
      setCheckout(true);
      return false;
    }
    setSaveNotice("");
    const savingIdentity = saveIdentity();
    explicitlySaved.current = "";
    setBusy(true);
    try {
      await pendingAutoSave.current;
      if (adminPreset) {
        const r = await updateReadyPaper(paper.id, paper, edits);
        const notice = r.ok
          ? "Admin preset save হয়েছে। মূল PDF বদলায়নি।"
          : r.error;
        setMessage(notice);
        setSaveNotice(notice);
        if (r.ok) explicitlySaved.current = savingIdentity;
        else return false;
      } else {
        if (paid) {
          const r = await saveReadyPurchase(receipt, snapshot(), selected);
          if (!r.ok) {
            setMessage(r.error);
            setSaveNotice("সেভ হয়নি: " + r.error);
            return false;
          }
        }
        if (paid) explicitlySaved.current = savingIdentity;
        if (paid)
          setSaveNotice(
            "প্রশ্নপত্র সেভ হয়েছে। সংরক্ষিত প্রশ্নপত্র থেকে আবার খুলতে পারবেন।",
          );
        try {
          await saveLocal(key, {
            selected,
            edits,
            header,
            headerStyle,
            headerSettings,
            headerLine,
            headerGap,
          });
        } catch {
          if (!paid) throw new Error("Local save failed");
          setSaveNotice(
            "অ্যাকাউন্টে প্রশ্নপত্র সেভ হয়েছে। এই browser-এ অতিরিক্ত draft রাখা যায়নি।",
          );
        }
        setMessage(
          paid
            ? "প্রশ্নপত্র ও উত্তরপত্র অ্যাকাউন্টে save হয়েছে।"
            : "এই browser-এ draft save হয়েছে। কেনার পর account-এ save হবে।",
        );
      }
      return true;
    } catch {
      setMessage("Save হয়নি। Browser storage/সংযোগ পরীক্ষা করুন।");
      setSaveNotice(
        "সেভ সম্পন্ন হয়েছে কি না যাচাই করুন। সংরক্ষিত প্রশ্নপত্র খুলুন; না থাকলে সংযোগ ঠিক করে আবার চেষ্টা করুন।",
      );
      return false;
    } finally {
      setBusy(false);
    }
  }
  async function saveAndPreview() {
    if (previewInFlight.current || busy) return;
    if (replacementBox) {
      setMessage(
        "আগে নির্বাচিত অংশের লেখা প্রয়োগ করুন অথবা পরিবর্তন বাতিল করুন।",
      );
      return;
    }
    previewInFlight.current = true;
    try {
      // Use the same render's snapshot and wait for the server-confirmed save.
      // A failed checkout/save must never proceed to Preview or export.
      if (await save()) await preview();
    } finally {
      previewInFlight.current = false;
    }
  }
  async function restore() {
    try {
      const data = await loadLocal(key);
      if (!data) {
        setMessage("এই browser-এ draft নেই।");
        return;
      }
      const valid: Record<string, PageEdit> = {};
      for (const [k, v] of Object.entries(data.edits || {})) {
        if (+k >= 1 && +k <= pages.length) valid[k] = pageEditSchema.parse(v);
      }
      const selection = Array.isArray(data.selected)
        ? data.selected
            .filter(
              (n: unknown) =>
                Number.isInteger(n) &&
                Number(n) > 0 &&
                Number(n) <= pages.length,
            )
            .slice(0, 10)
        : [];
      setEdits(valid);
      setSelected([...new Set<number>(selection)]);
      if (
        data.header &&
        Object.values(data.header).every(
          (v) => typeof v === "string" && v.length <= 160,
        )
      )
        setHeader({
          school: "",
          exam: "",
          subject: paper.subject,
          time: "",
          marks: "",
          ...data.header,
        });
      setHeaderLine(
        typeof data.headerLine === "boolean" ? data.headerLine : true,
      );
      setHeaderGap(
        typeof data.headerGap === "number" && Number.isFinite(data.headerGap)
          ? Math.min(15, Math.max(0, data.headerGap))
          : 2,
      );
      setHeaderStyle(
        ["simple", "custom", "none"].includes(data.headerStyle)
          ? data.headerStyle
          : "simple",
      );
      setHeaderSettings(
        settingsSchema.parse(
          data.headerSettings || {
            info: { subject: paper.subject, cls: paper.grade },
          },
        ),
      );
      undo.current = {};
      redo.current = {};
      setPrintPages([]);
      setMessage("Draft খোলা হয়েছে।");
    } catch {
      setMessage("Draft খোলা যায়নি। মূল PDF ব্যবহার করুন।");
    }
  }
  return (
    <main
      className={`rp-root rp-studio rp-stage-${step}`}
      inert={exportingMarket}
      aria-busy={exportingMarket}
    >
      <div className="rp-studio-head" data-noprint>
        <Link href={adminPreset ? "/admin/ready-papers" : "/ready-papers"}>
          <ArrowLeft size={18} />
          Library
        </Link>
        <span className="rp-tag">
          {adminPreset ? "ADMIN PRESET" : "READY PAPER STUDIO"}
        </span>
      </div>
      <section className="rp-hero" data-noprint>
        <h1>{paper.title}</h1>
        <p>
          {paper.grade} · {paper.subject} · {paper.year} · {paper.source}
        </p>
        <div className="rp-steps">
          <span className={step === "select" ? "active" : ""}>
            ১. Page নির্বাচন
          </span>
          <span className={step === "edit" ? "active" : ""}>
            ২. সেটআপ ও Edit
          </span>
          <span className={step === "preview" ? "active" : ""}>
            ৩. Preview ও Print
          </span>
        </div>
      </section>
      {pageLoading ? (
        <PageLoader
          completed={pageProgress.completed}
          total={pageProgress.total}
        />
      ) : (
        <p role="status" className="rp-status" data-noprint>
          {message}
        </p>
      )}
      {pages.length > 0 && step === "select" && (
        <div className="rp-toolbar rp-studio-actions" data-noprint>
          <button onClick={() => setStep("select")}>
            Page নির্বাচন ({selected.length})
          </button>
          {selected.length > 0 && (
            <button
              className="rp-action-setup"
              disabled={busy}
              onClick={startSetup}
            >
              সেটআপে যান
            </button>
          )}
          <Link href="/ready-papers/saved">আমার প্রশ্নপত্র ও প্যাকেজ</Link>
          <button disabled={busy} onClick={save}>
            <Save size={16} />
            {adminPreset ? "Admin preset save" : "প্রশ্নপত্র সেভ করুন"}
          </button>
          {!adminPreset && (
            <button disabled={busy} onClick={restore}>
              Saved draft খুলুন
            </button>
          )}
        </div>
      )}
      {step === "select" && (
        <section data-noprint>
          <div className="rp-page-grid">
            {pages.map((src, i) => (
              <div
                className={`rp-page-card${selected.includes(i + 1) ? " selected" : ""}`}
                key={i}
              >
                <button
                  type="button"
                  className="rp-page-open"
                  aria-label={`Page ${i + 1} বড় করে দেখতে এখানে ক্লিক করুন`}
                  onClick={() => {
                    setViewer({ src, page: i + 1, selectable: true });
                    qualityPage(i + 1)
                      .then((high) =>
                        setViewer((old) =>
                          old?.page === i + 1 && old.selectable
                            ? { ...old, src: high }
                            : old,
                        ),
                      )
                      .catch(() =>
                        setMessage(
                          "বড় ছবি প্রস্তুত হয়নি। আবার খুলে চেষ্টা করুন।",
                        ),
                      );
                  }}
                >
                  <img src={src} alt={`মূল PDF page ${i + 1}`} loading="lazy" />
                  <span className="rp-page-open-rail">
                    <span className="rp-page-open-caption">
                      বড় করে দেখতে এখানে ক্লিক করুন
                    </span>
                  </span>
                </button>
                <div className="rp-page-actions">
                  <label className="rp-page-choice">
                    <input
                      type="checkbox"
                      checked={selected.includes(i + 1)}
                      onChange={() => togglePage(i + 1)}
                    />
                    Page {(i + 1).toLocaleString("bn-BD")}
                  </label>
                  <button
                    type="button"
                    className="rp-page-create"
                    disabled={busy}
                    aria-label={`Page ${(i + 1).toLocaleString("bn-BD")} দিয়ে প্রশ্নপত্র তৈরি করুন`}
                    onClick={() => createFromPage(i + 1)}
                  >
                    প্রশ্নপত্র তৈরি করুন
                  </button>
                </div>
              </div>
            ))}
          </div>
          {pages.length > 0 && (
            <p className="rp-muted">
              নির্বাচনের ক্রমেই page সাজবে; সেটআপে ক্রম বদলাতে পারবেন। Original
              scan অপরিবর্তিত থাকে।
            </p>
          )}
        </section>
      )}
      {step === "edit" && (
        <div className="rp-editor" data-noprint>
          <aside
            ref={controlsPanel}
            tabIndex={-1}
            aria-label="Page ও Header সম্পাদনা"
            id="rp-edit-controls"
            className={`rp-panel rp-controls${controlsOpen ? " rp-controls-open" : ""}`}
          >
            <div className="rp-controls-heading">
              <h2>Page ও Header</h2>
              <button
                type="button"
                className="rp-controls-done"
                onClick={closeControls}
              >
                প্রিভিউতে ফিরুন ↓
              </button>
            </div>
            <div className="rp-order">
              {selected.map((n, i) => (
                <div key={n}>
                  <button
                    className={active === n ? "active" : ""}
                    onClick={() => {
                      setActive(n);
                      setOriginal(false);
                    }}
                  >
                    Page {n}
                  </button>
                  <button
                    aria-label={`Page ${n} আগে নিন`}
                    disabled={i === 0}
                    onClick={() =>
                      setSelected((v) => {
                        const a = [...v];
                        [a[i - 1], a[i]] = [a[i], a[i - 1]];
                        return a;
                      })
                    }
                  >
                    ↑
                  </button>
                  <button
                    aria-label={`Page ${n} পরে নিন`}
                    disabled={i === selected.length - 1}
                    onClick={() =>
                      setSelected((v) => {
                        const a = [...v];
                        [a[i], a[i + 1]] = [a[i + 1], a[i]];
                        return a;
                      })
                    }
                  >
                    ↓
                  </button>
                </div>
              ))}
            </div>
            <details open>
              <summary>Page Setup — ফন্ট ও মার্জিন</summary>
              <label>
                প্রশ্ন ও হেডারের ফন্ট
                <select
                  aria-label="প্রশ্ন ও হেডারের ফন্ট"
                  value={headerSettings.cfg.font}
                  onChange={(e) => {
                    setHeaderSettings({
                      ...headerSettings,
                      cfg: {
                        ...headerSettings.cfg,
                        font: e.target.value as PaperFont,
                      },
                    });
                    setPrintPages([]);
                  }}
                >
                  {Object.entries(paperFontLabels).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </label>
              <p className="rp-muted">
                স্ক্যানের মূল ছবির ফন্ট বদলায় না; হেডার ও নতুন/বদলানো লেখায়
                নির্বাচিত ফন্ট প্রযোজ্য।
              </p>
              <label>
                পেজ মার্জিন
                <select
                  aria-label="পেজ মার্জিন"
                  value={paperMarginMode(headerSettings.cfg)}
                  onChange={(e) => {
                    if (e.target.value === "custom") return;
                    setHeaderSettings({
                      ...headerSettings,
                      cfg: {
                        ...headerSettings.cfg,
                        ...paperMarginPresets[
                          e.target.value as "normal" | "narrow"
                        ],
                      },
                    });
                    setPrintPages([]);
                  }}
                >
                  <option value="normal">Normal — সাধারণ</option>
                  <option value="narrow">Narrow — কম মার্জিন</option>
                  <option value="custom" disabled>
                    Custom — নিজস্ব
                  </option>
                </select>
              </label>
              <button disabled={busy} onClick={save}>
                <Save size={16} /> প্রশ্নপত্র সেভ করুন
              </button>
              {!adminPreset && (
                <button disabled={busy} onClick={restore}>
                  Saved draft খুলুন
                </button>
              )}
              <Link href="/ready-papers/saved">আমার প্রশ্নপত্র ও প্যাকেজ</Link>
            </details>
            <details open>
              <summary>প্রথম selected page-এর Header</summary>
              {adminPreset && (
                <p className="rp-muted">
                  Admin preset save শুধু page-এর image edits সংরক্ষণ করে। নিজের
                  header account-এ রাখতে Header Manager-এর Save ব্যবহার করুন;
                  এটি সবার PDF preset-এ যুক্ত হবে না।
                </p>
              )}
              <label>
                হেডারের ধরন
                <select
                  value={headerStyle}
                  onChange={(e) => {
                    setHeaderStyle(e.target.value as typeof headerStyle);
                    setPrintPages([]);
                  }}
                >
                  <option value="simple">সাধারণ হেডার</option>
                  <option value="custom">Smart Header / Dynamic Header</option>
                  <option value="none">হেডার ছাড়া</option>
                </select>
              </label>
              {headerStyle !== "none" && (
                <>
                  <label>
                    <input
                      type="checkbox"
                      checked={headerLine}
                      onChange={(e) => setHeaderLine(e.target.checked)}
                    />
                    হেডারের নিচের লাইন দেখান
                  </label>
                  <label>
                    হেডার–প্রশ্নের gap · {headerGap} mm
                    <input
                      aria-label="হেডার প্রশ্নের gap"
                      type="range"
                      min="0"
                      max="15"
                      step=".5"
                      value={headerGap}
                      onChange={(e) => setHeaderGap(+e.target.value)}
                    />
                  </label>
                </>
              )}
              {headerStyle === "custom" && (
                <>
                  <HeaderManager
                    settings={headerSettings}
                    update={(value) => {
                      setHeaderSettings(value);
                      setPrintPages([]);
                    }}
                  />
                  <p className="rp-muted">
                    আপনার আগে save করা Smart/Dynamic header-ও এখানে পাবেন। একটি
                    header নির্বাচন করুন; header শুধু প্রথম selected page-এ।
                  </p>
                  {headerSettings.header.enabled && (
                    <div
                      className="rp-custom-header-preview"
                      style={{
                        fontFamily: paperFonts[headerSettings.cfg.font],
                      }}
                    >
                      <HeaderPreview header={currentHeader(headerSettings)} />
                    </div>
                  )}
                </>
              )}
              {headerStyle === "simple" && (
                <>
                  {(
                    ["school", "exam", "subject", "time", "marks"] as const
                  ).map((field, i) => (
                    <label key={field}>
                      {
                        [
                          "প্রতিষ্ঠানের নাম",
                          "পরীক্ষার নাম",
                          "বিষয়",
                          "সময়",
                          "পূর্ণমান",
                        ][i]
                      }
                      <input
                        value={header[field]}
                        maxLength={160}
                        onChange={(e) => {
                          setHeader((v) => ({ ...v, [field]: e.target.value }));
                          setPrintPages([]);
                        }}
                      />
                    </label>
                  ))}
                </>
              )}
              <p className="rp-muted">
                Header শুধু প্রথম selected page-এ; প্রশ্নের ওপর বসবে না।
              </p>
            </details>
            <h3>Page {active} · Clean ও Crop</h3>
            <label>
              Mode
              <select
                value={edit.mode}
                onChange={(e) =>
                  update({ mode: e.target.value as PageEdit["mode"] })
                }
              >
                <option value="original">Original</option>
                <option value="clean">Auto-clean · Grayscale</option>
                <option value="bw">Black & White</option>
              </select>
            </label>
            <fieldset>
              <legend>হালকা নীল watermark কমান</legend>
              <label>
                মাত্রা · {Math.round(edit.blueWatermark * 100)}%
                <input
                  aria-label="নীল watermark কমানোর মাত্রা"
                  type="range"
                  min="0"
                  max="1"
                  step=".1"
                  value={edit.blueWatermark}
                  onChange={(e) => update({ blueWatermark: +e.target.value })}
                />
              </label>
              <button
                type="button"
                onClick={() =>
                  update({ blueWatermark: edit.blueWatermark ? 0 : 1 })
                }
              >
                {edit.blueWatermark
                  ? "Watermark filter বন্ধ করুন"
                  : "নীল watermark কমিয়ে দেখুন"}
              </button>
              <p className="rp-muted">
                শুধু অনুমতিপ্রাপ্ত PDF-এ ব্যবহার করুন। নীল diagram/লেখাও হালকা
                হতে পারে; Original-এর সঙ্গে মিলিয়ে প্রশ্ন, অপশন ও টেবিল যাচাই
                করুন। কালো/ধূসর watermark বা হারানো লেখা উদ্ধার করে না।
              </p>
            </fieldset>
            <label>
              পরিষ্কারের মাত্রা
              <input
                type="range"
                min="0"
                max="1"
                step=".1"
                value={edit.strength}
                onChange={(e) => update({ strength: +e.target.value })}
              />
            </label>
            <label>
              বাঁকা scan সোজা করুন ({edit.deskew}°)
              <input
                type="range"
                min="-10"
                max="10"
                step=".5"
                value={edit.deskew}
                onChange={(e) => update({ deskew: +e.target.value })}
              />
            </label>
            <div className="rp-margin-tools">
              <h3>মার্জিন ও Crop</h3>
              <div className="rp-toolbar">
                <button
                  onClick={() =>
                    update({
                      rotation: ((edit.rotation + 90) %
                        360) as PageEdit["rotation"],
                      masks: [],
                      texts: [],
                    })
                  }
                >
                  <RotateCw size={15} />
                  ঘোরান
                </button>
                <button
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      const suggestion = await suggestMargins(
                        pages[active - 1],
                      );
                      update(suggestion);
                      setMessage(
                        "শুধু বাইরের সাদা margin-এর প্রস্তাব। লেখা/marks অক্ষত আছে কি না দেখে নিন।",
                      );
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  <Crop size={15} />
                  Auto margin
                </button>
              </div>
              {(["top", "bottom", "left", "right"] as const).map((side, i) => (
                <label key={side}>
                  {["ওপর", "নিচ", "বাম", "ডান"][i]} crop ·{" "}
                  {Math.round(edit[side] * 100)}%
                  <input
                    type="range"
                    min="0"
                    max={i < 2 ? ".35" : ".2"}
                    step=".005"
                    value={edit[side]}
                    onChange={(e) => update({ [side]: +e.target.value })}
                  />
                </label>
              ))}
            </div>
            <ReadyTextEditor
              text={text}
              onText={setText}
              size={size}
              onSize={setSize}
              font={headerSettings.cfg.font}
              onFont={(font) => {
                setHeaderSettings({
                  ...headerSettings,
                  cfg: { ...headerSettings.cfg, font },
                });
                setPrintPages([]);
              }}
              style={textStyle}
              onStyle={setTextStyle}
            />
            {replacementBox && (
              <div className="rp-region-editor" data-noprint>
                <p>
                  নির্বাচিত অংশের প্রশ্ন, উদ্দীপক, অপশন ও উপপ্রশ্ন একসঙ্গে লিখতে
                  পারেন। চিত্র থাকলে ঢাকার আগে যাচাই করুন। মূল PDF অপরিবর্তিত
                  থাকবে।
                </p>
                <button disabled={ocrBusy || busy} onClick={readRegion}>
                  {ocrBusy ? "লেখা পড়ছি…" : "এই অংশের লেখা পড়ুন (OCR)"}
                </button>
                {ocrBusy && (
                  <button onClick={() => ocrAbort.current?.abort()}>
                    পড়া বাতিল
                  </button>
                )}
                <button
                  disabled={ocrBusy || busy || !text.trim()}
                  onClick={applyReplacement}
                >
                  যাচাই করে লেখা প্রয়োগ করুন
                </button>
                <button
                  onClick={() => {
                    ocrAbort.current?.abort();
                    setReplacementBox(null);
                    setEditingText(null);
                  }}
                >
                  পরিবর্তন বাতিল
                </button>
              </div>
            )}
            {edit.texts.length > 0 && (
              <details>
                <summary>যোগ করা লেখা Edit করুন</summary>
                {edit.texts.map((t, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setEditingText(index);
                      setReplacementBox({
                        x: t.x,
                        y: t.y,
                        w: t.w ?? 1 - t.x,
                        h: t.h ?? Math.max(0.01, 1 - t.y),
                      });
                      setText(t.text);
                      setSize(t.size);
                      setTextStyle(t.style || {});
                    }}
                  >
                    {index + 1}. {t.text.slice(0, 45)}
                  </button>
                ))}
              </details>
            )}
            <div className="rp-toolbar">
              <button
                className={tool === "replace" ? "active" : ""}
                onClick={() => {
                  setTool("replace");
                  setOriginal(false);
                  setMessage(
                    "Edit: প্রশ্নের পুরো অংশ ঘিরে বক্স টানুন; তারপর লেখা পড়ে বা লিখে যাচাই করে প্রয়োগ করুন।",
                  );
                }}
              >
                প্রশ্নের লেখা Edit
              </button>
              <button
                className={tool === "view" ? "active" : ""}
                onClick={() => setTool("view")}
              >
                দেখুন
              </button>
              <button
                className={tool === "erase" ? "active" : ""}
                onClick={() => {
                  setTool("erase");
                  setOriginal(false);
                }}
              >
                <Eraser size={15} />
                ঢেকে দিন
              </button>
              <button
                className={tool === "text" ? "active" : ""}
                onClick={() => {
                  setTool("text");
                  setOriginal(false);
                }}
              >
                <Type size={15} />
                লেখা বসান
              </button>
            </div>
            <p className="rp-muted">
              ঢাকতে page-এ box টানুন; লেখা বসাতে tap করুন। এটি image edit—মূল
              PDF থেকে তথ্য স্থায়ীভাবে মুছে যায় না।
            </p>
            <div className="rp-toolbar">
              <button onClick={() => history(true)}>
                <Undo2 size={15} />
                Undo
              </button>
              <button onClick={() => history(false)}>
                <Redo2 size={15} />
                Redo
              </button>
              <button
                onClick={() => {
                  if (confirm("এই page-এর edit reset করবেন?"))
                    update(freshEdit());
                }}
              >
                Reset page
              </button>
            </div>
            <button
              className="rp-action-print"
              disabled={busy}
              onClick={saveAndPreview}
            >
              <Printer size={16} />
              Save &amp; Print Preview
            </button>
          </aside>
          <section className="rp-canvas-panel">
            <div className="rp-toolbar">
              <strong>Page {active}</strong>
              <button
                ref={controlsToggle}
                type="button"
                className="rp-mobile-controls"
                aria-expanded={controlsOpen}
                aria-controls="rp-edit-controls"
                onClick={() =>
                  controlsOpen ? closeControls() : setControlsOpen(true)
                }
              >
                {controlsOpen ? "Edit controls বন্ধ" : "Header ও Edit controls"}
              </button>
              <button
                onClick={() => {
                  if (liveReview && liveReviewPage === active)
                    setViewer({
                      src: liveReview,
                      page: active,
                      selectable: false,
                    });
                }}
              >
                বড় করে দেখুন ⤢
              </button>
              <button
                className="rp-action-print"
                disabled={busy}
                onClick={saveAndPreview}
              >
                Save &amp; Print Preview
              </button>
              <button onClick={() => setOriginal((v) => !v)}>
                {original ? "Edited দেখুন" : "Original দেখুন"}
              </button>
            </div>
            <div className="rp-toolbar">
              <button
                aria-pressed={placementMode}
                onClick={() => {
                  setPlacementMode((v) => !v);
                  setTool("view");
                  setOriginal(false);
                }}
              >
                প্রশ্নের আকার ও অবস্থান {placementMode ? "বন্ধ" : "ঠিক করুন"}
              </button>
              <span className="rp-muted">
                ঢেকে দিন / লেখা বসান বেছে এই A4 পাতাতেই কাজ করুন।
              </span>
            </div>
            <section
              className="rp-live-review"
              aria-label="সেটআপের সরাসরি A4 রিভিউ"
              aria-busy={reviewPending}
            >
              <h3>সরাসরি A4 রিভিউ ও Edit</h3>
              <p className="rp-muted" role="status">
                {reviewPending
                  ? "রিভিউ আপডেট হচ্ছে…"
                  : "হেডার ও Edit-এর ফল এখানেই দেখুন।"}
              </p>
              {active !== selected[0] && (
                <p className="rp-muted">
                  হেডার শুধু প্রথম নির্বাচিত পৃষ্ঠায় থাকবে।{" "}
                  <button onClick={() => setActive(selected[0])}>
                    হেডারসহ প্রথম পৃষ্ঠা দেখুন
                  </button>
                </p>
              )}
              <PrintFrame>
                <article className="rp-print-sheet" style={sheetStyle}>
                  {renderPageHeader(active === selected[0])}
                  {liveReview && liveReviewPage === active ? (
                    <PlacedQuestion
                      src={liveReview}
                      page={active}
                      value={edit}
                      movable={
                        !original &&
                        !reviewPending &&
                        tool === "view" &&
                        placementMode
                      }
                      onChange={(value) => placePage(active, value)}
                    >
                      {!original && !reviewPending && tool !== "view" && (
                        <RasterTools
                          key={`${active}:${tool}:${liveReview}`}
                          tool={tool}
                          edit={edit}
                          onCommit={commitRaster}
                        />
                      )}
                    </PlacedQuestion>
                  ) : (
                    <div className="rp-print-content">
                      <p role="status">প্রশ্নের ছবি প্রস্তুত হচ্ছে…</p>
                    </div>
                  )}
                </article>
              </PrintFrame>
            </section>
            <p className="rp-muted">
              মূল scan-এর resolution-ই print-এর সীমা। ক্ষুদ্র punctuation ও
              table line দেখে clean mode বাছুন। Rotation করলে overlay reset হয়।
            </p>
          </section>
        </div>
      )}
      {step === "preview" && (
        <>
          <div className="rp-toolbar" data-noprint>
            <button className="rp-action-setup" onClick={() => setStep("edit")}>
              Edit-এ ফিরুন
            </button>
            <button
              disabled={
                busy ||
                !paid ||
                !selected.length ||
                (printKind === "questions" &&
                  printPages.length !== selected.length)
              }
              className="rp-action-print"
              onClick={() => window.print()}
            >
              <Printer size={16} />
              Print / Save PDF
            </button>
          </div>
          {printKind === "questions" && selected.length > 0 && (
            <section className="rp-panel" data-noprint>
              <h3>প্রশ্নপত্র Auto Fit ও অবস্থান</h3>
              <label>
                যে page ঠিক করবেন
                <select
                  value={selected.includes(active) ? active : selected[0]}
                  onChange={(e) => setActive(+e.target.value)}
                >
                  {selected.map((n) => (
                    <option key={n} value={n}>
                      মূল page {n}
                    </option>
                  ))}
                </select>
              </label>
              {(() => {
                const n = selected.includes(active) ? active : selected[0];
                const value = edits[n] || freshEdit();
                return (
                  <>
                    <div className="rp-toolbar">
                      <button onClick={() => placePage(n, defaultPlacement)}>
                        প্রশ্নপত্র Auto Fit / Reset
                      </button>
                      <button
                        onClick={() =>
                          placePage(n, { ...value, printScale: 0.85 })
                        }
                      >
                        ছোট করে সরানোর জায়গা করুন
                      </button>
                      <button
                        aria-pressed={placementMode}
                        onClick={() => setPlacementMode((v) => !v)}
                      >
                        {placementMode
                          ? "অবস্থান সম্পাদনা বন্ধ"
                          : "প্রশ্নের অবস্থান ঠিক করুন"}
                      </button>
                    </div>
                    <label>
                      আকার · {Math.round(value.printScale * 100)}% (সর্বোচ্চ
                      নিরাপদ fit)
                      <input
                        aria-label="প্রশ্নপত্রের আকার"
                        type="range"
                        min=".4"
                        max="1"
                        step=".01"
                        value={value.printScale}
                        onChange={(e) =>
                          placePage(n, {
                            ...value,
                            printScale: +e.target.value,
                          })
                        }
                      />
                    </label>
                    <label>
                      ওপর–নিচ অবস্থান
                      <input
                        aria-label="প্রশ্নপত্রের ওপর নিচ অবস্থান"
                        type="range"
                        min="0"
                        max="1"
                        step=".01"
                        value={value.printY}
                        onChange={(e) =>
                          placePage(n, { ...value, printY: +e.target.value })
                        }
                      />
                    </label>
                    <label>
                      বাম–ডান অবস্থান
                      <input
                        aria-label="প্রশ্নপত্রের বাম ডান অবস্থান"
                        type="range"
                        min="0"
                        max="1"
                        step=".01"
                        value={value.printX}
                        onChange={(e) =>
                          placePage(n, { ...value, printX: +e.target.value })
                        }
                      />
                    </label>
                  </>
                );
              })()}
              <p className="rp-muted">
                Border-এর ভেতরে ধরে সরান; চার কোণা বা পাশের handle ধরে টেনে আকার
                ঠিক করুন। পুরো fit-এ সরানোর জায়গা না থাকলে “ছোট করে সরানোর জায়গা
                করুন” চাপুন। অবস্থান সম্পাদনা চালু থাকলে মোবাইলে দুই আঙুলে pinch
                করে আকার, এক আঙুলে অবস্থান; কম্পিউটারে mouse wheel-এ আকার ও বাম
                click-drag-এ অবস্থান ঠিক করুন। Ctrl/⌘ + wheel ব্রাউজারের zoom-এর
                জন্য। সর্বোচ্চ fit-এ পৌঁছালে আর বড় হবে না। Auto Fit হেডারের
                নিচের জায়গায় অনুপাত ঠিক রেখে সর্বোচ্চ আকারে বসায়। ছবির ভেতরের
                সাদা জায়গা আগে Crop করুন। অবস্থান বদলাতে ফাঁকা জায়গা থাকতে হবে;
                পুরো জায়গা ভরে গেলে সেই দিকে সরবে না। Margin ও header
                অপরিবর্তিত; লেখা কাটা হবে না। Preview zoom শুধু স্ক্রিনে দেখার
                জন্য।
              </p>
            </section>
          )}
          <section
            className="rp-save-confirmation"
            data-noprint
            aria-label="প্রশ্নপত্র সংরক্ষণ"
          >
            <button disabled={busy || !selected.length} onClick={save}>
              <Save size={16} />{" "}
              {busy ? "অপেক্ষা করুন…" : "প্রশ্নপত্র সেভ করুন"}
            </button>
            {paid && receipt && printKind === "questions" && (
              <button disabled={busy} onClick={prepareMarketCopy}>
                Marketplace-এ বিক্রির কপি প্রস্তুত করুন
              </button>
            )}
            <p role="status">{saveNotice}</p>
            <Link href="/question-builder/saved">
              সংরক্ষিত প্রশ্নপত্র দেখুন →
            </Link>
          </section>
          <PrintFrame
            mobileActions={
              <>
                <button
                  className="rp-action-setup"
                  onClick={() => setStep("edit")}
                >
                  Edit-এ ফিরুন
                </button>
                <button
                  className="rp-action-print"
                  disabled={
                    busy ||
                    !paid ||
                    !selected.length ||
                    (printKind === "questions" &&
                      printPages.length !== selected.length)
                  }
                  onClick={() => window.print()}
                >
                  <Printer size={16} />
                  Print / Save PDF
                </button>
                {printKind === "questions" && (
                  <button
                    aria-pressed={placementMode}
                    onClick={() => setPlacementMode((v) => !v)}
                  >
                    {placementMode
                      ? "অবস্থান সম্পাদনা বন্ধ"
                      : "প্রশ্নের অবস্থান ঠিক করুন"}
                  </button>
                )}
              </>
            }
          >
            <section id="ready-print">
              {printPages.map((src, i) => (
                <article
                  className="rp-print-sheet"
                  style={sheetStyle}
                  key={selected[i]}
                >
                  {renderPageHeader(i === 0)}
                  <PlacedQuestion
                    src={src}
                    page={selected[i]}
                    value={edits[selected[i]] || freshEdit()}
                    movable={placementMode}
                    onChange={(value) => placePage(selected[i], value)}
                  />
                </article>
              ))}
            </section>
          </PrintFrame>
        </>
      )}
      {checkout && (
        <ReadyCheckout
          paperId={paper.id}
          sourceUrl={paper.url}
          selected={selected}
          snapshot={snapshot()}
          beforePurchase={async () => {
            await document.fonts.ready;
            const renderPage = async (n: number) => {
              if (!pages[n - 1]) throw new Error("Page unavailable");
              let base: string;
              try {
                base = await qualityPage(n);
              } catch (q) {
                // Validate with the already-loaded thumbnail when the
                // high-quality re-render fails; the purchased PDF is
                // re-rendered server-side, so output quality is unchanged.
                console.error("ready quality render failed", n, q);
                base = pages[n - 1];
              }
              const c = await renderEdited(
                base,
                edits[n] || freshEdit(),
                true,
                headerSettings.cfg.font,
              );
              c.width = c.height = 0;
            };
            const prepare = async () => {
              for (const n of selected) await renderPage(n);
            };
            try {
              await prepare();
            } catch (e) {
              // Mobile networks drop the quality render often; one retry after
              // logging keeps the real cause visible in the browser console.
              console.error("ready checkout page preparation failed", e);
              await new Promise((r) => setTimeout(r, 700));
              await prepare();
            }
          }}
          onClose={() => setCheckout(false)}
          onPaid={async (id) => {
            const saved = await getReadyPurchase(id);
            if (!saved) throw new Error("Saved purchase unavailable");
            setEdits(saved.snapshot.edits);
            setHeader(saved.snapshot.header);
            setHeaderStyle(saved.snapshot.headerStyle);
            setHeaderSettings(saved.snapshot.headerSettings);
            setHeaderLine(saved.snapshot.headerLine);
            setHeaderGap(saved.snapshot.headerGap);
            setReceipt(id);
            setPaidSelection(readySelectionIdentity(selected));
            setCheckout(false);
            setActive(selected[0]);
            setStep("edit");
            setMessage(
              "প্রশ্নপত্র ও সংশ্লিষ্ট উত্তরপত্র অ্যাকাউন্টে সংরক্ষিত।",
            );
          }}
        />
      )}
      {viewer && (
        <PageViewer
          {...viewer}
          selected={selected.includes(viewer.page)}
          onToggle={
            viewer.selectable ? () => togglePage(viewer.page) : undefined
          }
          onClose={() => setViewer(null)}
        />
      )}
    </main>
  );
}
